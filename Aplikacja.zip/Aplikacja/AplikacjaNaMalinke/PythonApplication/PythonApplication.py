from tkinter import *

import matplotlib.pyplot as plt
import numpy as np

#Przyklady wykresow
def Wlasna():
    print("dziala")
    nx = entry_1.get()
    ny = entry_2.get()
    nw = entry_3.get()

    #Prosta
    x1 = entry_4.get()
    x2 = entry_5.get()
    y1 = entry_6.get()
    y2 = entry_7.get()
    plt.plot([x1, x2], [y1, y2])
    plt.grid(True)
    plt.xlabel(nx)
    plt.ylabel(ny)
    plt.title(nw)
    plt.savefig("wlasny.png", dpi = 72)
    plt.show()

def Pusto():
    plt.xlabel("x")
    plt.ylabel("y")
    plt.grid(True)
    plt.title(" ")
    plt.savefig("fig2.png", dpi = 72)
    plt.show()

def Sinusek():
    x = np.linspace(0, np.pi * 2, 100)
    y = np.sin(x)
    plt.plot(x, y)
    plt.grid(True)
    plt.xlim(0, np.pi * 2)
    plt.xlabel("x")
    plt.ylabel("f(x) = sin(x)")
    plt.title("Wykres funkcji f(x) = sin(x)")
    plt.savefig("fig1.png", dpi = 72)
    plt.show()

def Cosinusek():
    x = np.linspace(0, np.pi * 2, 100)
    y = np.cos(x)
    plt.plot(x, y)
    plt.grid(True)
    plt.xlim(0, np.pi * 2)
    plt.xlabel("x")
    plt.ylabel("f(x) = cos(x)")
    plt.title("Wykres funkcji f(x) = cos(x)")
    plt.savefig("fig2.png", dpi = 72)
    plt.show()

#Komendy
def Aplikacja():
    print("dziala")
    nx = entry_1.get()
    ny = entry_2.get()
    nw = entry_3.get()
    print(nx,ny,nw);
    
def close_window(): 
    root.destroy()

#Okno glowne
root = Tk()
root.title("Aplikacja Graph")
root.geometry("320x240")

label_1 = Label(root, text="Nazwa X")
label_2 = Label(root, text="Nazwa Y")
label_3 = Label(root, text="Nazwa wykresu")
label_4 = Label(root, text="x1")
label_5 = Label(root, text="x2")
label_6 = Label(root, text="y1")
label_7 = Label(root, text="y2")

entry_1 = Entry(root)
entry_2 = Entry(root)
entry_3 = Entry(root)
entry_4 = Entry(root)
entry_5 = Entry(root)
entry_6 = Entry(root)
entry_7 = Entry(root)


label_1.grid(row=0)
label_2.grid(row=1)
label_3.grid(row=2)
label_4.grid(row=3)
label_5.grid(row=4)
label_6.grid(row=5)
label_7.grid(row=6)


entry_1.grid(row=0, column=1)
entry_2.grid(row=1, column=1)
entry_3.grid(row=2, column=1)
entry_4.grid(row=3, column=1)
entry_5.grid(row=4, column=1)
entry_6.grid(row=5, column=1)
entry_7.grid(row=6, column=1)

button_1 = Button(root, text="Rob wykres prostej przez dwa punkty", command = Wlasna)
#button_1.bind("<Button-1>", Aplikacja)
button_1.grid(row=8, column=1)

menu = Menu(root)
root.config(menu=menu)

#Menu wyboru
subMenu = Menu(menu)
subMenu2 = Menu(menu)
menu.add_cascade(label="Menu", menu=subMenu)
subMenu.add_command(label= "Wyjdz" , command=close_window)
menu.add_cascade(label="Wykresy", menu=subMenu2)
subMenu2.add_command(label= "Sinus" , command=Sinusek)
subMenu2.add_command(label= "Cosinus" , command=Cosinusek)
subMenu2.add_command(label= "Nic" , command=Pusto)

root.mainloop()